package com.example.whatstheweather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    EditText enterCity;
    Button button;
    String city;
    TextView showWeather ;


    public class DownloadTask extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... urls) {

            String result="";
            URL url;
            HttpURLConnection urlConnection =null;
            try {
                url = new URL(urls[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = urlConnection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int data = reader.read();
                while(data!=-1){
                    char current = (char) data;
                    result += current;
                    data = reader.read();

                }
                return result;

            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Failed to fetch city details", Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            try {
                String mainString=null;
                String mainString2=null;
                JSONObject jsonObject = new JSONObject(result);
                String weatherInfo = jsonObject.getString("weather");
                String mainInfo = jsonObject.getString("main");
                mainInfo += "helloworld";
                String[] arrOfStr = mainInfo.split("helloworld");
                String THP = arrOfStr[0];




                Log.i("Web Content main",mainInfo);

                JSONArray arr = new JSONArray(weatherInfo);
                JSONArray arr2 = new JSONArray(arrOfStr);

                for (int i = 0; i <arr.length() ; i++) {
                    JSONObject jsonPart = arr.getJSONObject(i);

                     mainString = jsonPart.getString("main");
                     mainString2 = jsonPart.getString("description");

                    Log.i("Web Content1", mainString+"->"+mainString2);
                }

                String pressure = null;
                String temp=null;
                String humidity=null;
                Pattern p = Pattern.compile("\"temp\":(.*?),");
                Matcher m = p.matcher(THP);
                while(m.find()){
                     temp = m.group(1);

                }
                 p = Pattern.compile("\"pressure\":(.*?),");
                 m = p.matcher(THP);
                while(m.find()){
                     pressure = m.group(1);

                }
                 p = Pattern.compile("\"humidity\":(.*?),");
                 m = p.matcher(THP);
                while(m.find()){
                     humidity = m.group(1);

                }

                Log.i("Web Content temp,humidity,pressure", temp+"->"+pressure + "-->" + humidity);
                if (mainString!="" && mainString2!=""&& temp!=""&&humidity!=""&&pressure!="") {

                    String finall = city.toUpperCase() +"\r\nWeather:" + mainString + "\r\nDescription:" + mainString2 + "\r\nTemperature:" + temp + "\r\nHumidity" + humidity + "\r\nPressure:" + pressure;
                    showWeather.setText(finall);
                }
                else Toast.makeText(MainActivity.this, "Failed to fetch city details", Toast.LENGTH_SHORT).show();






            } catch (JSONException e) {
                Log.i("Web Content1", "Exception");
                Toast.makeText(MainActivity.this, "Failed to fetch city details", Toast.LENGTH_SHORT).show();

                e.printStackTrace();
            }

            Log.i("Web Content", result);

        }
    }


    public void whatIsTheWeather(View view){
        city =  enterCity.getText().toString();



        //city = "Goa";
        if (city == "" || city ==null){
            Toast.makeText(this, "Enter a valid City name", Toast.LENGTH_SHORT).show();

        }else {

            InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            mgr.hideSoftInputFromWindow(enterCity.getWindowToken(), 0);
            String encodedCityName;
            if (city!=""){
            try {
                 encodedCityName = URLEncoder.encode( city, "UTF-8");
                 DownloadTask task =  new DownloadTask();
                task.execute("https://api.openweathermap.org/data/2.5/weather?q=" + encodedCityName + "&callback=&appid=24a39cdb3a49d80ca76ee16e8e7ee9b3");
                Toast.makeText(this, city, Toast.LENGTH_LONG).show();

                Log.i("Web Content1", "Done");
            } catch (Exception e) {
                Toast.makeText(this, "Enter a valid City name", Toast.LENGTH_LONG).show();

                //e.printStackTrace();
            }}
            else {
                Toast.makeText(this, "Enter a valid City name", Toast.LENGTH_LONG).show();

            }




        }

    }







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        enterCity =(EditText) findViewById(R.id.enterCity);
        button = (Button) findViewById(R.id.button);
        showWeather =(TextView) findViewById(R.id.showWeather);

        //DownloadTask task =  new DownloadTask();
        //task.execute("https://api.openweathermap.org/data/2.5/weather?q=" +"Allahabad"+"&callback=&appid=24a39cdb3a49d80ca76ee16e8e7ee9b3");








    }
}